const books = require('./books');
const reviews = require('./reviews');
module.exports = {
    books,
    reviews,
};
